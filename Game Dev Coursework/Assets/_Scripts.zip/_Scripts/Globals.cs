﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Globals : MonoBehaviour {
    public const string MENU_SCENE = "Menu";
    public const string CAR_SELECTION_SCENE = "CarSelection";
    public const string GAME_SCENE = "RaceTrackNew";
    public const string HELP_SCENE = "Help";
    public const string PLAYER_TYPE_SCENE = "PlayerTypeMenu";
    public const string GAME_SCENE_MULTIPLAYER = "RaceTrackMultiplayer";
    public const string GAME_SCENE_SPLITSCREEN = "RaceTrackSplitScreen";
}
